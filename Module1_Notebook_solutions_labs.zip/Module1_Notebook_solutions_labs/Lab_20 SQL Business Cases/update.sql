update sales_person
set store = "Miami" where id2 = 5;

update customers 
set email = "ppicasso@gmail.com"
where id2 = 1;

update customers 
set email = "lincoln@us.gov"
where id2 = 2;

update customers 
set email = "hello@napoleon.me"
where id2 = 3;

